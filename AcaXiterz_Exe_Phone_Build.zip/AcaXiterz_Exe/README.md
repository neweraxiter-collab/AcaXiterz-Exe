# AcaXiterz Exe — Android project

Standalone visual-only Android panel with a neon-blue theme and working UI toggles.

## Build APK using only your phone (GitHub Actions)
1. Sign in to GitHub in your phone browser and create a **new repository**.
2. Upload the contents of this folder to the repository (not the ZIP file itself). Make sure `app/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, and `.github/workflows/build-apk.yml` are at the repository root.
3. Open the repository's **Actions** tab. If prompted, enable Actions.
4. Select **Build AcaXiterz Exe APK**, tap **Run workflow**, then confirm.
5. Wait for the run to finish successfully. Open the completed run and download the artifact named `AcaXiterz-Exe-APK`.
6. Extract the downloaded artifact ZIP on your phone. It contains `app-debug.apk`; tap it to install.

This workflow uses a GitHub-hosted runner to compile the project. Internet access and a GitHub account are required. GitHub's mobile interface can vary; use the browser's desktop-site option if needed.

## Safety
This app only changes its own visual UI. It does not connect to, inject into, modify, or read Free Fire and contains no gameplay cheats or anti-cheat bypasses.
