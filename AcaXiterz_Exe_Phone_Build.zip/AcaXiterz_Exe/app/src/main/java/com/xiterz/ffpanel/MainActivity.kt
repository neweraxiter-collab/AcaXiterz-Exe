package com.xiterz.ffpanel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF050B18)
private val Panel = Color(0xFF0B1730)
private val Neon = Color(0xFF16C8FF)
private val Blue = Color(0xFF287BFF)
private val Muted = Color(0xFF9BB5D3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { XiterzApp() }
    }
}

@Composable
fun XiterzApp() {
    var selectedTab by remember { mutableStateOf("Menu") }
    var glow by remember { mutableStateOf(true) }
    var animations by remember { mutableStateOf(true) }
    var compact by remember { mutableStateOf(false) }
    var showTips by remember { mutableStateOf(true) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon,
            secondary = Blue,
            background = Night,
            surface = Panel
        )
    ) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Neon) {
                    NavigationBarItem(
                        selected = selectedTab == "Beranda",
                        onClick = { selectedTab = "Beranda" },
                        icon = { Icon(Icons.Default.Bolt, null) },
                        label = { Text("Beranda") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == "Menu",
                        onClick = { selectedTab = "Menu" },
                        icon = { Icon(Icons.Default.Tune, null) },
                        label = { Text("Menu") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == "Tentang",
                        onClick = { selectedTab = "Tentang" },
                        icon = { Icon(Icons.Default.Info, null) },
                        label = { Text("Tentang") }
                    )
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF07152D), Night, Color(0xFF020611)))
                    )
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(Brush.linearGradient(listOf(Neon, Blue)), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("X", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("AcaXiterz Exe", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("SAFE • STYLISH • USEFUL", color = Neon, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Icon(Icons.Default.Settings, contentDescription = "Pengaturan", tint = Neon)
                }

                when (selectedTab) {
                    "Beranda" -> {
                        HeaderCard(
                            title = "SELAMAT DATANG",
                            subtitle = "Panel visual mandiri untuk pengalaman yang lebih personal."
                        )
                        InfoCard("Status aplikasi", "Siap digunakan • Versi 1.0.0")
                        InfoCard("Catatan keamanan", "Aplikasi ini tidak terhubung ke Free Fire dan tidak mengubah file atau memori game.")
                    }
                    "Tentang" -> {
                        HeaderCard(
                            title = "TENTANG XITERZ",
                            subtitle = "Panel Android bertema biru neon untuk pengaturan tampilan aplikasi ini."
                        )
                        InfoCard("Dibuat untuk", "Kustomisasi tampilan, animasi, dan preferensi visual.")
                        InfoCard("Batasan", "Tidak menyediakan cheat gameplay, injeksi, pembacaan memori, atau bypass anti-cheat.")
                    }
                    else -> {
                        HeaderCard(
                            title = "CONTROL CENTER",
                            subtitle = "Atur tampilan panel sesuai selera kamu."
                        )
                        InfoCard("Mode", "VISUAL ONLY • Tidak mengubah gameplay")

                        ToggleCard(
                            title = "Efek neon",
                            subtitle = "Aktifkan aksen cahaya biru pada panel",
                            checked = glow,
                            onCheckedChange = { glow = it }
                        )
                        ToggleCard(
                            title = "Animasi antarmuka",
                            subtitle = "Preferensi animasi untuk tampilan panel",
                            checked = animations,
                            onCheckedChange = { animations = it }
                        )
                        ToggleCard(
                            title = "Tampilan ringkas",
                            subtitle = "Gunakan gaya kartu yang lebih sederhana",
                            checked = compact,
                            onCheckedChange = { compact = it }
                        )
                        ToggleCard(
                            title = "Tips keamanan",
                            subtitle = "Tampilkan pengingat penggunaan yang aman",
                            checked = showTips,
                            onCheckedChange = { showTips = it }
                        )

                        if (showTips) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF102441)),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth().border(1.dp, Neon.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                            ) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("⚠ PENGINGAT", color = Neon, fontWeight = FontWeight.Bold)
                                    Text(
                                        "Toggle hanya mengubah tampilan aplikasi ini. Tidak ada fitur yang memodifikasi Free Fire. Selalu patuhi aturan game.",
                                        color = Muted,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                        Text(
                            "AcaXiterz Exe • VISUAL PANEL",
                            color = if (glow) Neon else Muted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HeaderCard(title: String, subtitle: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, Neon.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
    ) {
        Column(
            Modifier.background(Brush.horizontalGradient(listOf(Color(0xFF102A50), Panel)))
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(title, color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text(subtitle, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun InfoCard(title: String, subtitle: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, Blue.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
fun ToggleCard(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().border(
            1.dp,
            if (checked) Neon.copy(alpha = 0.7f) else Blue.copy(alpha = 0.25f),
            RoundedCornerShape(16.dp)
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}
